import json
import boto3
import jsonpickle
import time
import signal
import math
import os
import numpy as np
import pandas as pd
import pandas as pd
import time
import uuid
from io import StringIO
def FilterNaja6(inputList):
    df1 = pd.read_csv(StringIO(inputList[0]),sep=',')
    df2 = pd.read_csv(StringIO(inputList[1]),sep=',')
    df3 = df1.merge(df2, on=["ORDER_ID"], how='inner')
    priceFilter = df3["SHOP_PRICE"]>10
    df3.sort_values('ORDER_ID', inplace=True)
    
    # print(first)
    # .to_csv(index=False)
    resultFilter = df3[priceFilter]
    min= resultFilter['ORDER_ID'].min()
    max = resultFilter['ORDER_ID'].max()
    print(math.floor((min)/10000))
    print(math.ceil(max/10000))
    listLink =[]
    for i in range(math.floor((min)/10000),math.ceil(max/10000)+1):
        print(i)
        key = "{0}/{1}/{2}.csv".format(os.environ['AWS_LAMBDA_FUNCTION_NAME'],i,time.time())
        # print(key)
        # raise Exception("eieie")
        if min >0:
            resultFilter = resultFilter.loc[resultFilter['ORDER_ID']>i*10000]
        splitDf = resultFilter.loc[resultFilter['ORDER_ID']<(i+1)*10000].to_csv(index=False)
        s3obj = boto3.client('s3')
        s3obj.put_object(Bucket="output-bucky", Key=key, Body=splitDf)
        listLink.append(key)
    return listLink
def lambda_handler(event, context):
   try:
       with Timeout(840):
           s3 = boto3.client('s3')
           bucket_in= 'p-lightweight-864'
           plusfile = event['input']
           input_data=[]
           for url in plusfile:
               r = s3.get_object(Bucket=bucket_in, Key=url)
               inputEach = r['Body'].read().decode()
               input_data.append(inputEach)
           if 'call_id' in input_data:
               input_data = json.loads(input_data)
               input_data = jsonpickle.decode(input_data['data'])
               compute = FilterNaja6(input_data)
               bucket_out= 'p-lightweight-867'
               compute = jsonpickle.encode(compute)
               compute = {'output':compute}
               compute = json.dumps(compute)
               s3.put_object(Bucket=bucket_out, Key=plusfile, Body=compute)
           else:
               compute = FilterNaja6(input_data)
               bucket_out= 'p-lightweight-867'
               compute = jsonpickle.encode(compute)
               compute = {'output':compute}
               compute = json.dumps(compute)
               s3.put_object(Bucket=bucket_out, Key=plusfile, Body=compute)
           return {
               'statusCode': 200,
           }
   except Timeout.Timeout:
       print ('Timeout')
class Timeout():
   class Timeout(Exception):
       pass
   def __init__(self, sec):
       self.sec = sec
   def __enter__(self):
       signal.signal(signal.SIGALRM, self.raise_timeout)
       signal.alarm(self.sec)
   def __exit__(self, *args):
       signal.alarm(0)
   def raise_timeout(self, *args):
       raise  TimeoutError('Execution time exceed the limit')
