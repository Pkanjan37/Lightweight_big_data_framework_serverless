import json
import boto3
import numpy as np
import time
# import pickle as pickle
# import click
# import pandas as pd
# import seaborn as sns
def compute_function(x):
    A = np.arange(1024**2, dtype=np.float64).reshape(1024, 1024)
    B = np.arange(1024**2, dtype=np.float64).reshape(1024, 1024)
def benchmark():
    t1 = time.time()
    N = 3
    # def f(x):
    #     return {'flops': compute_flops(compute_function, matn)}
def results_to_dataframe(benchmark_data):
    callset_id = benchmark_data['callset_id']
# def run_benchmark(workers, outfile, loopcount, matn):
def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket_in= 'xifer-pywren-118'
    plusfile = event['input']
    r = s3.get_object(Bucket=bucket_in, Key=plusfile)
    input_data = r['Body'].read().decode()
    received_data = json.loads(input_data)
    inputData = received_data['data']
    compute = compute_function(inputData)
    bucket_out= 'output-bucky'
    output_data = {'output':compute}
    output_data = json.dumps(output_data)
    s3.put_object(Bucket=bucket_out, Key=plusfile, Body=output_data)
    return {
        'statusCode': 200,
        'body': json.dumps(compute)
    }
