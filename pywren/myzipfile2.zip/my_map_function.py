import numpy as np
from sympy import *
def my_map_function(x):
    return my_map2(x) + 7
def my_map2(x):
    return x*3
def printNP(x):
    return np.random.randint(x, 10, size=[2,2])
def printEQ(x):
    x, y, z, t = symbols('x y z t')
    a = Rational(3,2)*pi + exp(I*x) / (x**2 + y)
    return a
